"""
***********************************
Author: Nichel Emmanuel
Assignment #9,
ICT-4370

Project Description: This program uses Python and Django to read from an external 
database of dogs and dog owners and display a table listing the names and statistics
of all dogs owned by a single dog owner in a web page on the user’s local machine.
 
************************************
 """
 
from django.shortcuts import render

# Create your views here.
from .models import Dog
from .models import Owner

# Create your views here.
def index(request):
    ownerObject = Owner.objects.get(ownerid=1)
    #ownerObjects = Owner.objects.all()
    dogObjects = Dog.objects.all()
    context = {'dogs': dogObjects, 'owner': ownerObject}
    #context = {'dogs': dogObjects, 'owners': dogOwnerObjects}
    return render(request, 'dogWeb/index.html', context)