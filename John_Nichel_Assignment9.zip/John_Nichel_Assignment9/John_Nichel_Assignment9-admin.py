"""
***********************************
Author: Nichel Emmanuel
Assignment #9,
ICT-4370

Project Description: This program uses Python and Django to read from an external 
database of dogs and dog owners and display a table listing the names and statistics
of all dogs owned by a single dog owner in a web page on the user’s local machine.
 
File Description:The file to import and register Django's models.
************************************
 """
 
from django.contrib import admin
# Import the app-defined Dog and Owner models.
from firstDogApp.models import Dog, Owner
# Register your models here.

# Register the Dog and Owner models.
admin.site.register(Dog)
admin.site.register(Owner)